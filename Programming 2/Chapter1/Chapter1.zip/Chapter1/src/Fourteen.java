import javax.swing.JOptionPane;
public class Fourteen {
	public static void main(String []args) {
		JOptionPane.showMessageDialog(null,"Hello World");
	}

}
