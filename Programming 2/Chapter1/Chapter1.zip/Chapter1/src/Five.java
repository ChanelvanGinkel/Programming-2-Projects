
public class Five {
	public static void main(String []args) {
		System.out.println("+------+");
		System.out.println("|Chanel|");
		System.out.println("+------+");
	}

}
