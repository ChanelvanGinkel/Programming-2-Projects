
public class Eleven {
	public static void main(String []args) {
		System.out.println(" NOW \n OR \n NEVER");
	}

}
