
public class Seven {
	public static void main(String []args) {
		System.out.println("  ^^^^^^^");
		System.out.println(" | 0   0 |");
		System.out.println("(|   o   |)");
		System.out.println(" |_______|");
	}

}
