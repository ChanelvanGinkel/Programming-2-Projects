
public class Ten {
	public static void main(String []args) {
		System.out.println("   ^_^");
		System.out.println("  |0 0| |------|");
		System.out.println("  ( o )<  Bark!|");
		System.out.println("  /|||  |------|");
		System.out.println("-( ||| ");
	}

}
