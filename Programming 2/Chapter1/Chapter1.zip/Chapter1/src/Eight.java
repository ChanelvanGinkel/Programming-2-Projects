
public class Eight {
	public static void main(String []args) {
		System.out.println("|######|////////////|");
		System.out.println("|######|////////////|");
		System.out.println("|######|////////////|");
		System.out.println("|************|%%%%%%|");
		System.out.println("|************|%%%%%%|");
		System.out.println("|************|%%%%%%|");
		System.out.println("|************|------|");
		System.out.println("|000000|llllllllllll|");
		System.out.println("|000000|llllllllllll|");
	}

}
