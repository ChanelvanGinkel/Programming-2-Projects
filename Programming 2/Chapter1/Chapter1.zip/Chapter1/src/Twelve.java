
public class Twelve {
	public static void main(String []args) {
		System.out.println("	GOLDFISH");
		System.out.println("  Goldfish, goldfish");
		System.out.println(" Swimming all around");
		System.out.println(" Never makes a sound.");
		System.out.println("Pretty little goldfish");
		System.out.println("   Never can talk.");
		System.out.println("All it does is wiggle");
		System.out.println("When it tires to walk!");
		System.out.println("- Author: Unknown");
	}

}
